import { useState, useEffect } from "react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, Legend } from "recharts";

// === MOCK DATA ===
const monthlyData = [
  { mes: "Jan", vd: 312, ameaca: 189, lesao: 145, feminicidio: 2, estupro: 38, stalking: 22, mpDesc: 15 },
  { mes: "Fev", vd: 298, ameaca: 176, lesao: 132, feminicidio: 1, estupro: 31, stalking: 19, mpDesc: 12 },
  { mes: "Mar", vd: 341, ameaca: 201, lesao: 158, feminicidio: 3, estupro: 42, stalking: 28, mpDesc: 18 },
  { mes: "Abr", vd: 287, ameaca: 168, lesao: 129, feminicidio: 1, estupro: 29, stalking: 16, mpDesc: 11 },
  { mes: "Mai", vd: 265, ameaca: 154, lesao: 118, feminicidio: 0, estupro: 27, stalking: 14, mpDesc: 9 },
  { mes: "Jun", vd: 309, ameaca: 183, lesao: 141, feminicidio: 2, estupro: 35, stalking: 21, mpDesc: 14 },
  { mes: "Jul", vd: 278, ameaca: 162, lesao: 125, feminicidio: 1, estupro: 30, stalking: 17, mpDesc: 10 },
  { mes: "Ago", vd: 325, ameaca: 195, lesao: 152, feminicidio: 2, estupro: 39, stalking: 25, mpDesc: 16 },
  { mes: "Set", vd: 356, ameaca: 210, lesao: 167, feminicidio: 3, estupro: 44, stalking: 30, mpDesc: 20 },
  { mes: "Out", vd: 338, ameaca: 198, lesao: 155, feminicidio: 2, estupro: 41, stalking: 26, mpDesc: 17 },
  { mes: "Nov", vd: 367, ameaca: 218, lesao: 172, feminicidio: 4, estupro: 47, stalking: 32, mpDesc: 22 },
  { mes: "Dez", vd: 389, ameaca: 231, lesao: 184, feminicidio: 3, estupro: 51, stalking: 35, mpDesc: 24 },
];

const municipioData = [
  { nome: "Palmas", total: 1287, vd: 612, feminicidio: 5 },
  { nome: "Araguaina", total: 834, vd: 398, feminicidio: 4 },
  { nome: "Gurupi", total: 521, vd: 248, feminicidio: 2 },
  { nome: "Porto Nacional", total: 389, vd: 185, feminicidio: 2 },
  { nome: "Paraiso do TO", total: 312, vd: 149, feminicidio: 1 },
  { nome: "Colinas do TO", total: 267, vd: 127, feminicidio: 1 },
  { nome: "Guarai", total: 198, vd: 94, feminicidio: 1 },
  { nome: "Tocantinopolis", total: 176, vd: 84, feminicidio: 0 },
  { nome: "Dianopolis", total: 145, vd: 69, feminicidio: 1 },
  { nome: "Miracema do TO", total: 132, vd: 63, feminicidio: 0 },
];

const regiaoData = [
  { regiao: "Central", total: 1876, pct: 32.4 },
  { regiao: "Norte", total: 1312, pct: 22.7 },
  { regiao: "Sul", total: 987, pct: 17.1 },
  { regiao: "Sudeste", total: 823, pct: 14.2 },
  { regiao: "Bico do Papagaio", total: 787, pct: 13.6 },
];

const comparativoAnual = [
  { ano: "2021", total: 4890, vd: 2834, feminicidio: 18 },
  { ano: "2022", total: 5234, vd: 3012, feminicidio: 21 },
  { ano: "2023", total: 5567, vd: 3198, feminicidio: 19 },
  { ano: "2024", total: 5789, vd: 3345, feminicidio: 24 },
  { ano: "2025", total: 3865, vd: 2285, feminicidio: 17 },
];

const tipologiaDistrib = [
  { name: "Viol. Domestica", value: 3865, color: "#C9A84C" },
  { name: "Ameaca", value: 2285, color: "#8B6914" },
  { name: "Lesao Corporal", value: 1778, color: "#D4B96A" },
  { name: "Estupro", value: 454, color: "#E8D5A0" },
  { name: "Stalking", value: 285, color: "#6B4E8A" },
  { name: "Desc. MP", value: 188, color: "#9B7DB8" },
  { name: "Feminicidio", value: 24, color: "#FF4D4D" },
];

const COLORS = {
  bg: "#0a0614",
  bgCard: "#110d1f",
  bgCardHover: "#1a1430",
  border: "#1e1635",
  borderGold: "#C9A84C33",
  gold: "#C9A84C",
  goldLight: "#D4B96A",
  goldDim: "#8B6914",
  cream: "#F5EDD6",
  creamDim: "#C4B89A",
  purple: "#6B4E8A",
  purpleLight: "#9B7DB8",
  red: "#FF4D4D",
  redDim: "#CC3333",
  green: "#4CAF50",
  greenDim: "#2E7D32",
  textPrimary: "#F5EDD6",
  textSecondary: "#9B8FB0",
  textMuted: "#6B5F80",
};

const tabs = [
  { id: "visao", label: "Visao Geral" },
  { id: "serie", label: "Serie Historica" },
  { id: "territorio", label: "Territorio" },
  { id: "ranking", label: "Ranking Municipal" },
  { id: "metodologia", label: "Metodologia" },
  { id: "glossario", label: "Glossario" },
];

// === COMPONENTS ===
function StatCard({ label, value, delta, deltaLabel, icon, accent }) {
  const isPositive = delta > 0;
  return (
    <div style={{
      background: `linear-gradient(135deg, ${COLORS.bgCard} 0%, ${COLORS.bg} 100%)`,
      border: `1px solid ${accent || COLORS.borderGold}`,
      borderRadius: 12,
      padding: "20px 24px",
      position: "relative",
      overflow: "hidden",
      minWidth: 0,
    }}>
      <div style={{
        position: "absolute", top: -20, right: -20, width: 80, height: 80,
        borderRadius: "50%", background: `${accent || COLORS.gold}08`,
      }} />
      <div style={{ fontSize: 12, color: COLORS.textSecondary, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 8, fontFamily: "'Cinzel', serif" }}>
        {icon} {label}
      </div>
      <div style={{ fontSize: 32, fontWeight: 700, color: accent || COLORS.gold, fontFamily: "'Playfair Display', serif", lineHeight: 1.1 }}>
        {typeof value === "number" ? value.toLocaleString("pt-BR") : value}
      </div>
      {delta !== undefined && (
        <div style={{ marginTop: 8, fontSize: 12, color: isPositive ? COLORS.red : COLORS.green, display: "flex", alignItems: "center", gap: 4 }}>
          <span>{isPositive ? "\u2191" : "\u2193"} {Math.abs(delta).toFixed(1)}%</span>
          <span style={{ color: COLORS.textMuted, marginLeft: 4 }}>{deltaLabel}</span>
        </div>
      )}
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <h3 style={{
      fontSize: 16, fontWeight: 600, color: COLORS.cream,
      fontFamily: "'Cinzel', serif", letterSpacing: 1,
      borderBottom: `1px solid ${COLORS.border}`,
      paddingBottom: 10, marginBottom: 20, marginTop: 32,
    }}>
      {children}
    </h3>
  );
}

function ChartCard({ title, children, style: extraStyle }) {
  return (
    <div style={{
      background: COLORS.bgCard,
      border: `1px solid ${COLORS.border}`,
      borderRadius: 12,
      padding: 24,
      ...extraStyle,
    }}>
      {title && (
        <div style={{ fontSize: 13, color: COLORS.textSecondary, textTransform: "uppercase", letterSpacing: 1.2, marginBottom: 16, fontFamily: "'Cinzel', serif" }}>
          {title}
        </div>
      )}
      {children}
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload) return null;
  return (
    <div style={{
      background: COLORS.bg, border: `1px solid ${COLORS.borderGold}`,
      borderRadius: 8, padding: "12px 16px", fontSize: 12,
    }}>
      <div style={{ color: COLORS.gold, fontWeight: 600, marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || COLORS.cream, marginBottom: 2 }}>
          {p.name}: <strong>{p.value}</strong>
        </div>
      ))}
    </div>
  );
}

// === TAB VIEWS ===
function VisaoGeral() {
  const totalRegistros = monthlyData.reduce((a, m) => a + m.vd + m.ameaca + m.lesao + m.feminicidio + m.estupro + m.stalking + m.mpDesc, 0);
  const totalVD = monthlyData.reduce((a, m) => a + m.vd, 0);
  const totalFem = monthlyData.reduce((a, m) => a + m.feminicidio, 0);
  const totalEstupro = monthlyData.reduce((a, m) => a + m.estupro, 0);
  const totalMP = monthlyData.reduce((a, m) => a + m.mpDesc, 0);
  const totalStalking = monthlyData.reduce((a, m) => a + m.stalking, 0);

  return (
    <div>
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
        gap: 16,
        marginBottom: 32,
      }}>
        <StatCard label="Total de Registros" value={totalRegistros} delta={3.8} deltaLabel="vs. ano anterior" icon="" />
        <StatCard label="Violencia Domestica" value={totalVD} delta={4.2} deltaLabel="vs. ano anterior" icon="" />
        <StatCard label="Feminicidio" value={totalFem} delta={-11.1} deltaLabel="vs. ano anterior" accent={COLORS.red} icon="" />
        <StatCard label="Estupro" value={totalEstupro} delta={2.1} deltaLabel="vs. ano anterior" icon="" />
        <StatCard label="Desc. Med. Protetiva" value={totalMP} delta={8.3} deltaLabel="vs. ano anterior" icon="" />
        <StatCard label="Stalking" value={totalStalking} delta={12.5} deltaLabel="vs. ano anterior" icon="" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
        <ChartCard title="Evolucao Mensal - 2025 (Principais Tipologias)">
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="gradVD" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.gold} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.gold} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradAmeaca" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.purpleLight} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.purpleLight} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="vd" name="Viol. Domestica" stroke={COLORS.gold} fill="url(#gradVD)" strokeWidth={2} />
              <Area type="monotone" dataKey="ameaca" name="Ameaca" stroke={COLORS.purpleLight} fill="url(#gradAmeaca)" strokeWidth={2} />
              <Line type="monotone" dataKey="lesao" name="Lesao Corporal" stroke={COLORS.goldDim} strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="estupro" name="Estupro" stroke={COLORS.creamDim} strokeWidth={1.5} dot={false} />
              <Legend wrapperStyle={{ fontSize: 11, color: COLORS.textMuted }} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Distribuicao por Tipologia">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tipologiaDistrib}
                cx="50%" cy="50%"
                innerRadius={55} outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {tipologiaDistrib.map((entry, i) => (
                  <Cell key={i} fill={entry.color} stroke={COLORS.bg} strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
            {tipologiaDistrib.map((t, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: COLORS.textSecondary }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: t.color, display: "inline-block" }} />
                {t.name}
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginTop: 20 }}>
        <ChartCard title="Comparativo Anual - Total de Registros">
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={comparativoAnual}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="ano" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total" name="Total" fill={COLORS.gold} radius={[4, 4, 0, 0]} />
              <Bar dataKey="vd" name="Viol. Domestica" fill={COLORS.goldDim} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Feminicidio - Serie Anual">
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={comparativoAnual}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="ano" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="feminicidio" name="Feminicidio" fill={COLORS.red} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function SerieHistorica() {
  const [indicador, setIndicador] = useState("vd");
  const options = [
    { key: "vd", label: "Violencia Domestica", color: COLORS.gold },
    { key: "ameaca", label: "Ameaca", color: COLORS.purpleLight },
    { key: "lesao", label: "Lesao Corporal", color: COLORS.goldDim },
    { key: "feminicidio", label: "Feminicidio", color: COLORS.red },
    { key: "estupro", label: "Estupro", color: COLORS.creamDim },
    { key: "stalking", label: "Stalking", color: COLORS.purple },
    { key: "mpDesc", label: "Desc. Med. Protetiva", color: COLORS.goldLight },
  ];
  const sel = options.find(o => o.key === indicador);

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
        {options.map(o => (
          <button key={o.key} onClick={() => setIndicador(o.key)} style={{
            background: indicador === o.key ? o.color + "22" : "transparent",
            border: `1px solid ${indicador === o.key ? o.color : COLORS.border}`,
            color: indicador === o.key ? o.color : COLORS.textSecondary,
            borderRadius: 20, padding: "6px 14px", fontSize: 12, cursor: "pointer",
            fontFamily: "'Cinzel', serif", letterSpacing: 0.5,
            transition: "all 0.2s",
          }}>
            {o.label}
          </button>
        ))}
      </div>

      <ChartCard title={`Serie Mensal - ${sel.label} (2025)`}>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
            <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
            <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
            <Tooltip content={<CustomTooltip />} />
            <Line type="monotone" dataKey={indicador} name={sel.label} stroke={sel.color} strokeWidth={3} dot={{ fill: sel.color, r: 5 }} activeDot={{ r: 7, stroke: COLORS.bg, strokeWidth: 2 }} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ marginTop: 20 }}>
        <ChartCard title="Todas as Tipologias - Comparativo Mensal">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              {options.map(o => (
                <Line key={o.key} type="monotone" dataKey={o.key} name={o.label} stroke={o.color} strokeWidth={1.5} dot={false} />
              ))}
              <Legend wrapperStyle={{ fontSize: 10, color: COLORS.textMuted }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function Territorio() {
  const maxTotal = Math.max(...regiaoData.map(r => r.total));
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Distribuicao por Regiao Integrada">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={regiaoData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis type="number" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis dataKey="regiao" type="category" tick={{ fill: COLORS.textSecondary, fontSize: 11 }} width={120} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total" name="Total" fill={COLORS.gold} radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Mapa de Concentracao Territorial">
          <div style={{ position: "relative", height: 300, display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <svg viewBox="0 0 300 400" style={{ width: "100%", height: "100%", maxHeight: 280 }}>
              {/* Simplified TO state shape */}
              <path d="M100,30 L180,20 L220,60 L240,120 L260,180 L250,240 L230,300 L200,350 L160,380 L120,370 L80,340 L60,280 L50,220 L55,160 L70,100 L80,60 Z"
                fill={COLORS.bgCard} stroke={COLORS.borderGold} strokeWidth={1.5} />
              {/* Region heat spots */}
              {[
                { cx: 150, cy: 200, r: 32, label: "Central", val: 1876, op: 0.9 },
                { cx: 170, cy: 80, r: 26, label: "Norte", val: 1312, op: 0.7 },
                { cx: 130, cy: 330, r: 22, label: "Sul", val: 987, op: 0.55 },
                { cx: 210, cy: 260, r: 20, label: "Sudeste", val: 823, op: 0.45 },
                { cx: 110, cy: 50, r: 18, label: "Bico", val: 787, op: 0.4 },
              ].map((spot, i) => (
                <g key={i}>
                  <circle cx={spot.cx} cy={spot.cy} r={spot.r} fill={COLORS.gold} opacity={spot.op} />
                  <circle cx={spot.cx} cy={spot.cy} r={spot.r * 1.4} fill={COLORS.gold} opacity={spot.op * 0.2} />
                  <text x={spot.cx} y={spot.cy - 4} textAnchor="middle" fill={COLORS.bg} fontSize={8} fontWeight="bold">{spot.label}</text>
                  <text x={spot.cx} y={spot.cy + 8} textAnchor="middle" fill={COLORS.bg} fontSize={7}>{spot.val}</text>
                </g>
              ))}
            </svg>
            <div style={{ textAlign: "center", fontSize: 10, color: COLORS.textMuted, marginTop: 4 }}>
              Representacao esquematica - dados simulados
            </div>
          </div>
        </ChartCard>
      </div>

      <div style={{ marginTop: 20 }}>
        <ChartCard title="Participacao Percentual por Regiao">
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {regiaoData.map((r, i) => (
              <div key={i} style={{ flex: 1, minWidth: 140 }}>
                <div style={{ fontSize: 12, color: COLORS.textSecondary, marginBottom: 6 }}>{r.regiao}</div>
                <div style={{ background: COLORS.bg, borderRadius: 6, height: 28, overflow: "hidden", position: "relative" }}>
                  <div style={{
                    width: `${r.pct}%`, height: "100%",
                    background: `linear-gradient(90deg, ${COLORS.goldDim}, ${COLORS.gold})`,
                    borderRadius: 6, transition: "width 0.8s ease",
                    display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 8,
                  }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: COLORS.bg }}>{r.pct}%</span>
                  </div>
                </div>
                <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 3 }}>{r.total.toLocaleString("pt-BR")} registros</div>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>
    </div>
  );
}

function RankingMunicipal() {
  return (
    <div>
      <ChartCard title="Top 10 Municipios - Total de Registros (2025)">
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={municipioData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
            <XAxis type="number" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
            <YAxis dataKey="nome" type="category" tick={{ fill: COLORS.textSecondary, fontSize: 11 }} width={130} axisLine={{ stroke: COLORS.border }} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="total" name="Total" fill={COLORS.gold} radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ marginTop: 20 }}>
        <ChartCard title="Detalhamento por Municipio">
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead>
                <tr style={{ borderBottom: `2px solid ${COLORS.borderGold}` }}>
                  {["Pos.", "Municipio", "Total", "Viol. Domestica", "Feminicidio", "% do Total"].map(h => (
                    <th key={h} style={{ padding: "10px 12px", textAlign: "left", color: COLORS.gold, fontFamily: "'Cinzel', serif", fontSize: 11, letterSpacing: 1, textTransform: "uppercase" }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {municipioData.map((m, i) => {
                  const totalGeral = municipioData.reduce((a, x) => a + x.total, 0);
                  return (
                    <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}`, transition: "background 0.2s" }}
                      onMouseEnter={e => e.currentTarget.style.background = COLORS.bgCardHover}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "10px 12px", color: COLORS.textMuted }}>{i + 1}</td>
                      <td style={{ padding: "10px 12px", color: COLORS.cream, fontWeight: 500 }}>{m.nome}</td>
                      <td style={{ padding: "10px 12px", color: COLORS.gold, fontWeight: 700 }}>{m.total.toLocaleString("pt-BR")}</td>
                      <td style={{ padding: "10px 12px", color: COLORS.textSecondary }}>{m.vd.toLocaleString("pt-BR")}</td>
                      <td style={{ padding: "10px 12px", color: m.feminicidio > 0 ? COLORS.red : COLORS.textMuted, fontWeight: m.feminicidio > 0 ? 700 : 400 }}>
                        {m.feminicidio}
                      </td>
                      <td style={{ padding: "10px 12px", color: COLORS.textSecondary }}>{((m.total / totalGeral) * 100).toFixed(1)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </ChartCard>
      </div>
    </div>
  );
}

function Metodologia() {
  return (
    <ChartCard>
      <h3 style={{ fontSize: 18, color: COLORS.gold, fontFamily: "'Playfair Display', serif", marginBottom: 20 }}>
        Nota Metodologica
      </h3>
      {[
        { t: "Orgao Responsavel", d: "Secretaria da Seguranca Publica do Estado do Tocantins (SSP-TO), por meio do Observatorio de Seguranca Publica Voltado aos Crimes Envolvendo Mulheres (OBSMULHER-TO)." },
        { t: "Fontes de Dados", d: "Boletim de Ocorrencia Eletronico, sistemas da Policia Militar e Policia Civil do Tocantins. Quando integrados: SINAN/SUS, TJ-TO, MP-TO." },
        { t: "Periodicidade", d: "Indicadores essenciais sao atualizados mensalmente, ate o 15o dia util do mes subsequente. Indicadores recomendaveis sao atualizados trimestralmente." },
        { t: "Classificacao", d: "As tipologias seguem a classificacao penal brasileira e as definicoes operacionais do SINESP e do Anuario Brasileiro de Seguranca Publica." },
        { t: "Anonimizacao", d: "Nenhum dado publicado permite identificacao direta ou indireta de vitimas, agressores ou testemunhas. Indicadores municipais so sao publicados quando n >= 5." },
        { t: "Limitacoes", d: "Os dados refletem registros oficiais e podem apresentar subnotificacao inerente a crimes de genero. O painel nao substitui pesquisas vitimologicas ou de prevalencia." },
        { t: "Retificacao", d: "Eventuais correcoes sao publicadas com nota de errata e controle de versao." },
        { t: "Contato", d: "obsmulher@ssp.to.gov.br" },
      ].map((item, i) => (
        <div key={i} style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.cream, fontFamily: "'Cinzel', serif", letterSpacing: 0.5, marginBottom: 4 }}>
            {item.t}
          </div>
          <div style={{ fontSize: 13, color: COLORS.textSecondary, lineHeight: 1.6 }}>
            {item.d}
          </div>
        </div>
      ))}
    </ChartCard>
  );
}

function Glossario() {
  const terms = [
    { t: "Violencia Domestica e Familiar", d: "Qualquer acao ou omissao baseada no genero que cause morte, lesao, sofrimento fisico, sexual ou psicologico e dano moral ou patrimonial no ambito da unidade domestica, da familia ou de relacao intima de afeto (Lei n. 11.340/2006)." },
    { t: "Feminicidio", d: "Homicidio praticado contra a mulher por razoes da condicao de sexo feminino, quando envolve violencia domestica e familiar ou menosprezo/discriminacao a condicao de mulher (art. 121, par. 2o-A, CP)." },
    { t: "Medida Protetiva de Urgencia", d: "Medida judicial prevista na Lei Maria da Penha destinada a proteger a mulher em situacao de violencia domestica e familiar (arts. 22 a 24 da Lei n. 11.340/2006)." },
    { t: "Stalking / Perseguicao", d: "Perseguicao reiterada que ameace a integridade fisica ou psicologica, restringindo a capacidade de locomocao ou perturbando a liberdade ou privacidade da vitima (art. 147-A, CP)." },
    { t: "Violencia Psicologica", d: "Conduta que cause dano emocional e diminuicao da autoestima da mulher, mediante ameaca, constrangimento, humilhacao, manipulacao, isolamento, chantagem, ridicularizacao ou outro meio que lhe cause prejuizo a saude psicologica (Lei n. 14.188/2021)." },
    { t: "Violencia Patrimonial", d: "Conduta que configure retencao, subtracao ou destruicao de bens, valores, documentos ou recursos economicos da mulher (art. 7o, IV, Lei n. 11.340/2006)." },
    { t: "LGPD", d: "Lei Geral de Protecao de Dados Pessoais (Lei n. 13.709/2018)." },
    { t: "AISP", d: "Area Integrada de Seguranca Publica." },
  ];
  return (
    <ChartCard>
      <h3 style={{ fontSize: 18, color: COLORS.gold, fontFamily: "'Playfair Display', serif", marginBottom: 20 }}>
        Glossario de Termos
      </h3>
      {terms.map((item, i) => (
        <div key={i} style={{ marginBottom: 16, paddingBottom: 12, borderBottom: i < terms.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.gold, marginBottom: 4 }}>{item.t}</div>
          <div style={{ fontSize: 12, color: COLORS.textSecondary, lineHeight: 1.6 }}>{item.d}</div>
        </div>
      ))}
    </ChartCard>
  );
}

// === MAIN APP ===
export default function PainelMulherTO() {
  const [activeTab, setActiveTab] = useState("visao");
  const [periodo, setPeriodo] = useState("2025");
  const [filtroAberto, setFiltroAberto] = useState(false);

  const tabContent = {
    visao: <VisaoGeral />,
    serie: <SerieHistorica />,
    territorio: <Territorio />,
    ranking: <RankingMunicipal />,
    metodologia: <Metodologia />,
    glossario: <Glossario />,
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: `linear-gradient(180deg, ${COLORS.bg} 0%, #060410 100%)`,
      color: COLORS.cream,
      fontFamily: "'Segoe UI', -apple-system, sans-serif",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet" />

      {/* HEADER */}
      <header style={{
        background: `linear-gradient(135deg, ${COLORS.bg} 0%, #12091e 50%, ${COLORS.bg} 100%)`,
        borderBottom: `1px solid ${COLORS.borderGold}`,
        padding: "20px 32px",
        position: "sticky", top: 0, zIndex: 100,
        backdropFilter: "blur(12px)",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 1400, margin: "0 auto" }}>
          <div>
            <div style={{ fontSize: 11, color: COLORS.textMuted, letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>
              SSP-TO | OBSMULHER-TO
            </div>
            <h1 style={{
              fontSize: 22, fontWeight: 700, color: COLORS.gold,
              fontFamily: "'Cinzel', serif", letterSpacing: 1.5, margin: 0,
            }}>
              PAINEL VIRTUAL DA SEGURANCA DA MULHER
            </h1>
            <div style={{ fontSize: 12, color: COLORS.textSecondary, marginTop: 2, fontFamily: "'Playfair Display', serif" }}>
              Estado do Tocantins
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 10, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Ultima Atualizacao</div>
            <div style={{ fontSize: 13, color: COLORS.goldLight, fontWeight: 600 }}>15/03/2026</div>
            <div style={{
              marginTop: 6, display: "inline-block",
              background: COLORS.green + "22", border: `1px solid ${COLORS.green}44`,
              borderRadius: 12, padding: "2px 10px", fontSize: 10, color: COLORS.green,
            }}>
              VERSAO PUBLICA
            </div>
          </div>
        </div>
      </header>

      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px 60px" }}>
        {/* FILTROS */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "16px 0", marginBottom: 8,
          borderBottom: `1px solid ${COLORS.border}`,
        }}>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <span style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Periodo:</span>
            {["2023", "2024", "2025"].map(y => (
              <button key={y} onClick={() => setPeriodo(y)} style={{
                background: periodo === y ? COLORS.gold + "22" : "transparent",
                border: `1px solid ${periodo === y ? COLORS.gold : COLORS.border}`,
                color: periodo === y ? COLORS.gold : COLORS.textSecondary,
                borderRadius: 6, padding: "5px 14px", fontSize: 12, cursor: "pointer",
                transition: "all 0.2s",
              }}>
                {y}
              </button>
            ))}
          </div>
          <button onClick={() => setFiltroAberto(!filtroAberto)} style={{
            background: "transparent", border: `1px solid ${COLORS.border}`,
            color: COLORS.textSecondary, borderRadius: 6, padding: "5px 14px",
            fontSize: 12, cursor: "pointer",
          }}>
            {filtroAberto ? "Fechar Filtros" : "Mais Filtros"}
          </button>
        </div>

        {filtroAberto && (
          <div style={{
            background: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
            borderRadius: 8, padding: 20, marginBottom: 20,
            display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16,
          }}>
            {[
              { label: "Municipio", options: ["Todos", "Palmas", "Araguaina", "Gurupi", "Porto Nacional"] },
              { label: "Regiao", options: ["Todas", "Central", "Norte", "Sul", "Sudeste", "Bico do Papagaio"] },
              { label: "Natureza", options: ["Todas", "Viol. Domestica", "Ameaca", "Lesao Corporal", "Feminicidio", "Estupro"] },
            ].map((f, i) => (
              <div key={i}>
                <label style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1, display: "block", marginBottom: 6 }}>
                  {f.label}
                </label>
                <select style={{
                  width: "100%", background: COLORS.bg, border: `1px solid ${COLORS.border}`,
                  color: COLORS.cream, borderRadius: 6, padding: "8px 12px", fontSize: 12,
                }}>
                  {f.options.map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
            ))}
          </div>
        )}

        {/* TABS */}
        <div style={{
          display: "flex", gap: 0, marginBottom: 24,
          borderBottom: `1px solid ${COLORS.border}`,
          overflowX: "auto",
        }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              background: "transparent",
              border: "none",
              borderBottom: activeTab === tab.id ? `2px solid ${COLORS.gold}` : "2px solid transparent",
              color: activeTab === tab.id ? COLORS.gold : COLORS.textSecondary,
              padding: "12px 20px",
              fontSize: 12,
              fontFamily: "'Cinzel', serif",
              letterSpacing: 1,
              textTransform: "uppercase",
              cursor: "pointer",
              transition: "all 0.2s",
              whiteSpace: "nowrap",
            }}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* CONTENT */}
        {tabContent[activeTab]}
      </div>

      {/* FOOTER */}
      <footer style={{
        borderTop: `1px solid ${COLORS.borderGold}`,
        padding: "20px 32px",
        textAlign: "center",
        background: COLORS.bg,
      }}>
        <div style={{ fontSize: 11, color: COLORS.textMuted, lineHeight: 1.8 }}>
          <div>Secretaria da Seguranca Publica do Estado do Tocantins (SSP-TO)</div>
          <div>Observatorio de Seguranca Publica Voltado aos Crimes Envolvendo Mulheres (OBSMULHER-TO)</div>
          <div style={{ marginTop: 8, fontSize: 10, color: COLORS.textMuted }}>
            Dados anonimizados e agregados em conformidade com a LGPD (Lei n. 13.709/2018).
          </div>
          <div style={{ marginTop: 4, fontSize: 10, color: COLORS.textMuted }}>
            ESBOCO / PROTOTIPO - Dados simulados para fins de demonstracao do layout.
          </div>
        </div>
      </footer>
    </div>
  );
}
