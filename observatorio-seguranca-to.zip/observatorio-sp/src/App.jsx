import { useState } from "react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, Legend, ComposedChart } from "recharts";

// === MOCK DATA ===
const monthlyData = [
  { mes: "Jan", homicidio: 45, cvli: 48, roubo: 312, furto: 489, trafico: 87, armas: 34, prisoes: 156, flagrantes: 89 },
  { mes: "Fev", homicidio: 38, cvli: 41, roubo: 287, furto: 456, trafico: 79, armas: 31, prisoes: 142, flagrantes: 78 },
  { mes: "Mar", homicidio: 52, cvli: 56, roubo: 341, furto: 512, trafico: 94, armas: 42, prisoes: 178, flagrantes: 95 },
  { mes: "Abr", homicidio: 41, cvli: 44, roubo: 298, furto: 467, trafico: 82, armas: 29, prisoes: 149, flagrantes: 82 },
  { mes: "Mai", homicidio: 36, cvli: 39, roubo: 276, furto: 434, trafico: 71, armas: 27, prisoes: 134, flagrantes: 71 },
  { mes: "Jun", homicidio: 43, cvli: 47, roubo: 318, furto: 478, trafico: 88, armas: 36, prisoes: 162, flagrantes: 87 },
  { mes: "Jul", homicidio: 39, cvli: 42, roubo: 289, furto: 451, trafico: 76, armas: 32, prisoes: 147, flagrantes: 79 },
  { mes: "Ago", homicidio: 47, cvli: 51, roubo: 334, furto: 498, trafico: 91, armas: 39, prisoes: 171, flagrantes: 92 },
  { mes: "Set", homicidio: 54, cvli: 58, roubo: 356, furto: 523, trafico: 98, armas: 44, prisoes: 185, flagrantes: 101 },
  { mes: "Out", homicidio: 49, cvli: 53, roubo: 342, furto: 501, trafico: 93, armas: 41, prisoes: 176, flagrantes: 94 },
  { mes: "Nov", homicidio: 56, cvli: 61, roubo: 367, furto: 534, trafico: 102, armas: 47, prisoes: 192, flagrantes: 108 },
  { mes: "Dez", homicidio: 62, cvli: 67, roubo: 389, furto: 567, trafico: 112, armas: 52, prisoes: 208, flagrantes: 118 },
];

const municipioData = [
  { nome: "Palmas", pop: 313349, homicidio: 89, cvli: 96, roubo: 1287, furto: 2134, trafico: 312, taxa_cvli: 30.6 },
  { nome: "Araguaina", pop: 183381, homicidio: 67, cvli: 72, roubo: 834, furto: 1456, trafico: 198, taxa_cvli: 39.3 },
  { nome: "Gurupi", pop: 88496, homicidio: 34, cvli: 37, roubo: 521, furto: 876, trafico: 124, taxa_cvli: 41.8 },
  { nome: "Porto Nacional", pop: 53316, homicidio: 21, cvli: 23, roubo: 289, furto: 534, trafico: 67, taxa_cvli: 43.1 },
  { nome: "Paraiso do TO", pop: 52532, homicidio: 18, cvli: 20, roubo: 234, furto: 478, trafico: 54, taxa_cvli: 38.1 },
  { nome: "Colinas do TO", pop: 39351, homicidio: 15, cvli: 17, roubo: 178, furto: 356, trafico: 42, taxa_cvli: 43.2 },
  { nome: "Guarai", pop: 26074, homicidio: 11, cvli: 12, roubo: 134, furto: 267, trafico: 31, taxa_cvli: 46.0 },
  { nome: "Tocantinopolis", pop: 23401, homicidio: 9, cvli: 10, roubo: 112, furto: 223, trafico: 28, taxa_cvli: 42.7 },
  { nome: "Dianopolis", pop: 22439, homicidio: 8, cvli: 9, roubo: 98, furto: 198, trafico: 24, taxa_cvli: 40.1 },
  { nome: "Miracema do TO", pop: 18248, homicidio: 7, cvli: 8, roubo: 87, furto: 176, trafico: 21, taxa_cvli: 43.8 },
];

const regiaoData = [
  { regiao: "Central", pop: 456789, cvli: 145, roubo: 1876, furto: 3234, pct: 28.4 },
  { regiao: "Norte", pop: 312456, cvli: 112, roubo: 1312, furto: 2187, pct: 21.9 },
  { regiao: "Sul", pop: 234567, cvli: 89, roubo: 987, furto: 1654, pct: 17.4 },
  { regiao: "Sudeste", pop: 198234, cvli: 78, roubo: 823, furto: 1398, pct: 15.3 },
  { regiao: "Bico do Papagaio", pop: 178945, cvli: 87, roubo: 787, furto: 1287, pct: 17.0 },
];

const comparativoAnual = [
  { ano: "2020", cvli: 589, roubo: 4123, furto: 6234, trafico: 876, taxa_cvli: 37.2 },
  { ano: "2021", cvli: 612, roubo: 4356, furto: 6567, trafico: 923, taxa_cvli: 38.1 },
  { ano: "2022", cvli: 578, roubo: 4089, furto: 6123, trafico: 989, taxa_cvli: 35.4 },
  { ano: "2023", cvli: 534, roubo: 3876, furto: 5890, trafico: 1034, taxa_cvli: 32.1 },
  { ano: "2024", cvli: 498, roubo: 3654, furto: 5678, trafico: 1087, taxa_cvli: 29.6 },
  { ano: "2025", cvli: 511, roubo: 3809, furto: 5910, trafico: 1073, taxa_cvli: 30.1 },
];

const tipologiaDistrib = [
  { name: "Furto", value: 5910, color: "#C9A84C" },
  { name: "Roubo", value: 3809, color: "#8B6914" },
  { name: "Trafico", value: 1073, color: "#6B4E8A" },
  { name: "CVLI", value: 511, color: "#FF4D4D" },
  { name: "Armas", value: 454, color: "#9B7DB8" },
  { name: "Outros", value: 1243, color: "#D4B96A" },
];

const operacoesData = [
  { mes: "Jan", operacoes: 45, prisoes: 156, apreensoes: 89, veiculos: 34 },
  { mes: "Fev", operacoes: 38, prisoes: 142, apreensoes: 78, veiculos: 29 },
  { mes: "Mar", operacoes: 52, prisoes: 178, apreensoes: 95, veiculos: 41 },
  { mes: "Abr", operacoes: 41, prisoes: 149, apreensoes: 82, veiculos: 32 },
  { mes: "Mai", operacoes: 36, prisoes: 134, apreensoes: 71, veiculos: 27 },
  { mes: "Jun", operacoes: 48, prisoes: 162, apreensoes: 87, veiculos: 38 },
  { mes: "Jul", operacoes: 43, prisoes: 147, apreensoes: 79, veiculos: 33 },
  { mes: "Ago", operacoes: 51, prisoes: 171, apreensoes: 92, veiculos: 39 },
  { mes: "Set", operacoes: 56, prisoes: 185, apreensoes: 101, veiculos: 44 },
  { mes: "Out", operacoes: 53, prisoes: 176, apreensoes: 94, veiculos: 42 },
  { mes: "Nov", operacoes: 59, prisoes: 192, apreensoes: 108, veiculos: 48 },
  { mes: "Dez", operacoes: 64, prisoes: 208, apreensoes: 118, veiculos: 53 },
];

const COLORS = {
  bg: "#0a0614",
  bgCard: "#110d1f",
  bgCardHover: "#1a1430",
  border: "#1e1635",
  borderGold: "#C9A84C33",
  gold: "#C9A84C",
  goldLight: "#D4B96A",
  goldDim: "#8B6914",
  cream: "#F5EDD6",
  creamDim: "#C4B89A",
  purple: "#6B4E8A",
  purpleLight: "#9B7DB8",
  red: "#FF4D4D",
  redDim: "#CC3333",
  green: "#4CAF50",
  greenDim: "#2E7D32",
  blue: "#4A90D9",
  textPrimary: "#F5EDD6",
  textSecondary: "#9B8FB0",
  textMuted: "#6B5F80",
};

const tabs = [
  { id: "visao", label: "Visao Geral" },
  { id: "crimes", label: "Crimes Violentos" },
  { id: "patrimonio", label: "Crimes Patrimoniais" },
  { id: "operacional", label: "Indicadores Operacionais" },
  { id: "territorio", label: "Analise Territorial" },
  { id: "ranking", label: "Ranking Municipal" },
  { id: "metodologia", label: "Metodologia" },
];

// === CSV EXPORT FUNCTIONS ===
function convertToCSV(data, headers) {
  const headerRow = headers.map(h => h.label).join(";");
  const dataRows = data.map(row => 
    headers.map(h => {
      const val = row[h.key];
      return typeof val === "number" ? val.toString().replace(".", ",") : val;
    }).join(";")
  );
  return [headerRow, ...dataRows].join("\n");
}

function downloadCSV(data, headers, filename) {
  const csv = "\uFEFF" + convertToCSV(data, headers);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}_${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function DownloadButton({ onClick, label }) {
  return (
    <button onClick={onClick} style={{
      background: COLORS.gold + "22",
      border: `1px solid ${COLORS.gold}`,
      color: COLORS.gold,
      borderRadius: 6,
      padding: "8px 16px",
      fontSize: 12,
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      gap: 6,
      fontFamily: "'Cinzel', serif",
      letterSpacing: 0.5,
      transition: "all 0.2s",
    }}
    onMouseEnter={e => e.target.style.background = COLORS.gold + "44"}
    onMouseLeave={e => e.target.style.background = COLORS.gold + "22"}
    >
      <span style={{ fontSize: 14 }}>CSV</span> {label || "Baixar CSV"}
    </button>
  );
}

// === COMPONENTS ===
function StatCard({ label, value, delta, deltaLabel, accent, subtitle }) {
  const isPositive = delta > 0;
  return (
    <div style={{
      background: `linear-gradient(135deg, ${COLORS.bgCard} 0%, ${COLORS.bg} 100%)`,
      border: `1px solid ${accent || COLORS.borderGold}`,
      borderRadius: 12,
      padding: "20px 24px",
      position: "relative",
      overflow: "hidden",
      minWidth: 0,
    }}>
      <div style={{
        position: "absolute", top: -20, right: -20, width: 80, height: 80,
        borderRadius: "50%", background: `${accent || COLORS.gold}08`,
      }} />
      <div style={{ fontSize: 11, color: COLORS.textSecondary, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 6, fontFamily: "'Cinzel', serif" }}>
        {label}
      </div>
      <div style={{ fontSize: 28, fontWeight: 700, color: accent || COLORS.gold, fontFamily: "'Playfair Display', serif", lineHeight: 1.1 }}>
        {typeof value === "number" ? value.toLocaleString("pt-BR") : value}
      </div>
      {subtitle && (
        <div style={{ fontSize: 10, color: COLORS.textMuted, marginTop: 4 }}>{subtitle}</div>
      )}
      {delta !== undefined && (
        <div style={{ marginTop: 6, fontSize: 11, color: isPositive ? COLORS.red : COLORS.green, display: "flex", alignItems: "center", gap: 4 }}>
          <span>{isPositive ? "+" : ""}{delta.toFixed(1)}%</span>
          <span style={{ color: COLORS.textMuted, marginLeft: 4 }}>{deltaLabel}</span>
        </div>
      )}
    </div>
  );
}

function ChartCard({ title, children, style: extraStyle, onDownload, downloadLabel }) {
  return (
    <div style={{
      background: COLORS.bgCard,
      border: `1px solid ${COLORS.border}`,
      borderRadius: 12,
      padding: 24,
      ...extraStyle,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        {title && (
          <div style={{ fontSize: 13, color: COLORS.textSecondary, textTransform: "uppercase", letterSpacing: 1.2, fontFamily: "'Cinzel', serif" }}>
            {title}
          </div>
        )}
        {onDownload && <DownloadButton onClick={onDownload} label={downloadLabel} />}
      </div>
      {children}
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload) return null;
  return (
    <div style={{
      background: COLORS.bg, border: `1px solid ${COLORS.borderGold}`,
      borderRadius: 8, padding: "12px 16px", fontSize: 12,
    }}>
      <div style={{ color: COLORS.gold, fontWeight: 600, marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color || COLORS.cream, marginBottom: 2 }}>
          {p.name}: <strong>{typeof p.value === "number" ? p.value.toLocaleString("pt-BR") : p.value}</strong>
        </div>
      ))}
    </div>
  );
}

function DataTable({ data, columns, onDownload, title }) {
  return (
    <ChartCard title={title} onDownload={onDownload}>
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr style={{ borderBottom: `2px solid ${COLORS.borderGold}` }}>
              {columns.map(col => (
                <th key={col.key} style={{ 
                  padding: "10px 12px", textAlign: col.align || "left", 
                  color: COLORS.gold, fontFamily: "'Cinzel', serif", 
                  fontSize: 11, letterSpacing: 1, textTransform: "uppercase" 
                }}>
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}`, transition: "background 0.2s" }}
                onMouseEnter={e => e.currentTarget.style.background = COLORS.bgCardHover}
                onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                {columns.map(col => (
                  <td key={col.key} style={{ 
                    padding: "10px 12px", 
                    color: col.highlight && row[col.key] > col.highlightThreshold ? COLORS.red : 
                           col.accent ? col.accent : COLORS.textSecondary,
                    fontWeight: col.bold ? 700 : 400,
                    textAlign: col.align || "left",
                  }}>
                    {col.format ? col.format(row[col.key]) : 
                     typeof row[col.key] === "number" ? row[col.key].toLocaleString("pt-BR") : row[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </ChartCard>
  );
}

// === TAB VIEWS ===
function VisaoGeral() {
  const totals = monthlyData.reduce((acc, m) => ({
    homicidio: acc.homicidio + m.homicidio,
    cvli: acc.cvli + m.cvli,
    roubo: acc.roubo + m.roubo,
    furto: acc.furto + m.furto,
    trafico: acc.trafico + m.trafico,
    prisoes: acc.prisoes + m.prisoes,
  }), { homicidio: 0, cvli: 0, roubo: 0, furto: 0, trafico: 0, prisoes: 0 });

  const handleDownloadGeral = () => {
    downloadCSV(monthlyData, [
      { key: "mes", label: "Mes" },
      { key: "homicidio", label: "Homicidios" },
      { key: "cvli", label: "CVLI" },
      { key: "roubo", label: "Roubos" },
      { key: "furto", label: "Furtos" },
      { key: "trafico", label: "Trafico" },
      { key: "armas", label: "Apreensao Armas" },
      { key: "prisoes", label: "Prisoes" },
      { key: "flagrantes", label: "Flagrantes" },
    ], "dados_gerais_seguranca_to_2025");
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
        <DownloadButton onClick={handleDownloadGeral} label="Baixar Dados Gerais" />
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
        gap: 16,
        marginBottom: 32,
      }}>
        <StatCard label="CVLI" value={totals.cvli} delta={-6.2} deltaLabel="vs. 2024" subtitle="Crimes Violentos Letais" accent={COLORS.red} />
        <StatCard label="Homicidios" value={totals.homicidio} delta={-5.8} deltaLabel="vs. 2024" accent={COLORS.red} />
        <StatCard label="Roubos" value={totals.roubo} delta={4.2} deltaLabel="vs. 2024" />
        <StatCard label="Furtos" value={totals.furto} delta={4.1} deltaLabel="vs. 2024" />
        <StatCard label="Trafico" value={totals.trafico} delta={-1.3} deltaLabel="vs. 2024" accent={COLORS.purple} />
        <StatCard label="Prisoes Efetuadas" value={totals.prisoes} delta={8.7} deltaLabel="vs. 2024" accent={COLORS.green} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
        <ChartCard title="Evolucao Mensal - 2025" onDownload={handleDownloadGeral}>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="gradRoubo" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.gold} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.gold} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradFurto" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.purpleLight} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.purpleLight} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="furto" name="Furto" stroke={COLORS.purpleLight} fill="url(#gradFurto)" strokeWidth={2} />
              <Area type="monotone" dataKey="roubo" name="Roubo" stroke={COLORS.gold} fill="url(#gradRoubo)" strokeWidth={2} />
              <Line type="monotone" dataKey="cvli" name="CVLI" stroke={COLORS.red} strokeWidth={2} dot={false} />
              <Legend wrapperStyle={{ fontSize: 11, color: COLORS.textMuted }} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Distribuicao por Tipologia">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tipologiaDistrib}
                cx="50%" cy="50%"
                innerRadius={55} outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {tipologiaDistrib.map((entry, i) => (
                  <Cell key={i} fill={entry.color} stroke={COLORS.bg} strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
            {tipologiaDistrib.map((t, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: COLORS.textSecondary }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: t.color, display: "inline-block" }} />
                {t.name}
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      <div style={{ marginTop: 20 }}>
        <ChartCard 
          title="Serie Historica Anual - Taxa CVLI por 100 mil hab." 
          onDownload={() => downloadCSV(comparativoAnual, [
            { key: "ano", label: "Ano" },
            { key: "cvli", label: "CVLI" },
            { key: "roubo", label: "Roubos" },
            { key: "furto", label: "Furtos" },
            { key: "trafico", label: "Trafico" },
            { key: "taxa_cvli", label: "Taxa CVLI/100mil" },
          ], "serie_historica_anual_to")}
        >
          <ResponsiveContainer width="100%" height={280}>
            <ComposedChart data={comparativoAnual}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="ano" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis yAxisId="left" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar yAxisId="left" dataKey="cvli" name="CVLI (abs)" fill={COLORS.red} radius={[4, 4, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="taxa_cvli" name="Taxa/100mil" stroke={COLORS.gold} strokeWidth={3} dot={{ fill: COLORS.gold, r: 5 }} />
              <Legend wrapperStyle={{ fontSize: 11, color: COLORS.textMuted }} />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function CrimesViolentos() {
  const handleDownload = () => {
    downloadCSV(monthlyData, [
      { key: "mes", label: "Mes" },
      { key: "homicidio", label: "Homicidios" },
      { key: "cvli", label: "CVLI" },
    ], "crimes_violentos_to_2025");
  };

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="CVLI - Crimes Violentos Letais Intencionais" onDownload={handleDownload}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="cvli" name="CVLI" fill={COLORS.red} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Homicidios Dolosos">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="homicidio" name="Homicidios" stroke={COLORS.red} strokeWidth={3} dot={{ fill: COLORS.red, r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ marginTop: 20 }}>
        <ChartCard 
          title="Comparativo Anual - CVLI" 
          onDownload={() => downloadCSV(comparativoAnual, [
            { key: "ano", label: "Ano" },
            { key: "cvli", label: "CVLI" },
            { key: "taxa_cvli", label: "Taxa CVLI/100mil" },
          ], "cvli_anual_to")}
        >
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={comparativoAnual}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="ano" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="cvli" name="CVLI" fill={COLORS.red} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function CrimesPatrimoniais() {
  const handleDownload = () => {
    downloadCSV(monthlyData, [
      { key: "mes", label: "Mes" },
      { key: "roubo", label: "Roubos" },
      { key: "furto", label: "Furtos" },
    ], "crimes_patrimoniais_to_2025");
  };

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Roubos - Serie Mensal 2025" onDownload={handleDownload}>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="gradRoubo2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.gold} stopOpacity={0.4} />
                  <stop offset="95%" stopColor={COLORS.gold} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="roubo" name="Roubos" stroke={COLORS.gold} fill="url(#gradRoubo2)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Furtos - Serie Mensal 2025">
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="gradFurto2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.purpleLight} stopOpacity={0.4} />
                  <stop offset="95%" stopColor={COLORS.purpleLight} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="furto" name="Furtos" stroke={COLORS.purpleLight} fill="url(#gradFurto2)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div style={{ marginTop: 20 }}>
        <ChartCard 
          title="Comparativo Roubo vs Furto - Serie Anual"
          onDownload={() => downloadCSV(comparativoAnual, [
            { key: "ano", label: "Ano" },
            { key: "roubo", label: "Roubos" },
            { key: "furto", label: "Furtos" },
          ], "roubos_furtos_anual_to")}
        >
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={comparativoAnual}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="ano" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="roubo" name="Roubos" fill={COLORS.gold} radius={[4, 4, 0, 0]} />
              <Bar dataKey="furto" name="Furtos" fill={COLORS.purpleLight} radius={[4, 4, 0, 0]} />
              <Legend wrapperStyle={{ fontSize: 11, color: COLORS.textMuted }} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function Operacional() {
  const handleDownload = () => {
    downloadCSV(operacoesData, [
      { key: "mes", label: "Mes" },
      { key: "operacoes", label: "Operacoes" },
      { key: "prisoes", label: "Prisoes" },
      { key: "apreensoes", label: "Apreensoes Drogas" },
      { key: "veiculos", label: "Veiculos Recuperados" },
    ], "indicadores_operacionais_to_2025");
  };

  const totals = operacoesData.reduce((acc, m) => ({
    operacoes: acc.operacoes + m.operacoes,
    prisoes: acc.prisoes + m.prisoes,
    apreensoes: acc.apreensoes + m.apreensoes,
    veiculos: acc.veiculos + m.veiculos,
  }), { operacoes: 0, prisoes: 0, apreensoes: 0, veiculos: 0 });

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
        <DownloadButton onClick={handleDownload} label="Baixar Indicadores Operacionais" />
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
        gap: 16,
        marginBottom: 32,
      }}>
        <StatCard label="Operacoes Realizadas" value={totals.operacoes} delta={12.3} deltaLabel="vs. 2024" accent={COLORS.blue} />
        <StatCard label="Prisoes Efetuadas" value={totals.prisoes} delta={8.7} deltaLabel="vs. 2024" accent={COLORS.green} />
        <StatCard label="Apreensoes de Drogas" value={totals.apreensoes} delta={15.2} deltaLabel="vs. 2024" accent={COLORS.purple} />
        <StatCard label="Veiculos Recuperados" value={totals.veiculos} delta={9.4} deltaLabel="vs. 2024" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Operacoes e Prisoes - 2025" onDownload={handleDownload}>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={operacoesData}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="prisoes" name="Prisoes" fill={COLORS.green} radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="operacoes" name="Operacoes" stroke={COLORS.blue} strokeWidth={3} dot={{ fill: COLORS.blue, r: 4 }} />
              <Legend wrapperStyle={{ fontSize: 11, color: COLORS.textMuted }} />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Apreensoes e Recuperacoes">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={operacoesData}>
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis dataKey="mes" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="apreensoes" name="Apreensoes Drogas" stroke={COLORS.purple} strokeWidth={2} dot={{ fill: COLORS.purple, r: 4 }} />
              <Line type="monotone" dataKey="veiculos" name="Veiculos Recuperados" stroke={COLORS.gold} strokeWidth={2} dot={{ fill: COLORS.gold, r: 4 }} />
              <Legend wrapperStyle={{ fontSize: 11, color: COLORS.textMuted }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function Territorio() {
  const handleDownload = () => {
    downloadCSV(regiaoData, [
      { key: "regiao", label: "Regiao" },
      { key: "pop", label: "Populacao" },
      { key: "cvli", label: "CVLI" },
      { key: "roubo", label: "Roubos" },
      { key: "furto", label: "Furtos" },
      { key: "pct", label: "% do Total" },
    ], "dados_regionais_to_2025");
  };

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <ChartCard title="Distribuicao por Regiao Integrada" onDownload={handleDownload}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={regiaoData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
              <XAxis type="number" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
              <YAxis dataKey="regiao" type="category" tick={{ fill: COLORS.textSecondary, fontSize: 11 }} width={120} axisLine={{ stroke: COLORS.border }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="cvli" name="CVLI" fill={COLORS.red} radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Mapa de Concentracao - CVLI">
          <div style={{ position: "relative", height: 300, display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <svg viewBox="0 0 300 400" style={{ width: "100%", height: "100%", maxHeight: 280 }}>
              <path d="M100,30 L180,20 L220,60 L240,120 L260,180 L250,240 L230,300 L200,350 L160,380 L120,370 L80,340 L60,280 L50,220 L55,160 L70,100 L80,60 Z"
                fill={COLORS.bgCard} stroke={COLORS.borderGold} strokeWidth={1.5} />
              {[
                { cx: 150, cy: 200, r: 30, label: "Central", val: 145, op: 0.9 },
                { cx: 170, cy: 80, r: 24, label: "Norte", val: 112, op: 0.75 },
                { cx: 130, cy: 330, r: 20, label: "Sul", val: 89, op: 0.6 },
                { cx: 210, cy: 260, r: 18, label: "Sudeste", val: 78, op: 0.5 },
                { cx: 110, cy: 50, r: 19, label: "Bico", val: 87, op: 0.55 },
              ].map((spot, i) => (
                <g key={i}>
                  <circle cx={spot.cx} cy={spot.cy} r={spot.r} fill={COLORS.red} opacity={spot.op} />
                  <circle cx={spot.cx} cy={spot.cy} r={spot.r * 1.4} fill={COLORS.red} opacity={spot.op * 0.15} />
                  <text x={spot.cx} y={spot.cy - 4} textAnchor="middle" fill={COLORS.cream} fontSize={8} fontWeight="bold">{spot.label}</text>
                  <text x={spot.cx} y={spot.cy + 8} textAnchor="middle" fill={COLORS.cream} fontSize={7}>{spot.val}</text>
                </g>
              ))}
            </svg>
            <div style={{ textAlign: "center", fontSize: 10, color: COLORS.textMuted, marginTop: 4 }}>
              Representacao esquematica - dados simulados
            </div>
          </div>
        </ChartCard>
      </div>

      <div style={{ marginTop: 20 }}>
        <ChartCard title="Participacao Percentual por Regiao">
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {regiaoData.map((r, i) => (
              <div key={i} style={{ flex: 1, minWidth: 140 }}>
                <div style={{ fontSize: 12, color: COLORS.textSecondary, marginBottom: 6 }}>{r.regiao}</div>
                <div style={{ background: COLORS.bg, borderRadius: 6, height: 28, overflow: "hidden", position: "relative" }}>
                  <div style={{
                    width: `${r.pct}%`, height: "100%",
                    background: `linear-gradient(90deg, ${COLORS.goldDim}, ${COLORS.gold})`,
                    borderRadius: 6, transition: "width 0.8s ease",
                    display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 8,
                  }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: COLORS.bg }}>{r.pct}%</span>
                  </div>
                </div>
                <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 3 }}>{r.cvli} CVLI</div>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>
    </div>
  );
}

function RankingMunicipal() {
  const columns = [
    { key: "pos", label: "Pos.", format: (_, i) => i + 1 },
    { key: "nome", label: "Municipio", accent: COLORS.cream, bold: true },
    { key: "pop", label: "Populacao" },
    { key: "cvli", label: "CVLI", highlight: true, highlightThreshold: 50, accent: COLORS.red },
    { key: "taxa_cvli", label: "Taxa CVLI/100mil", format: v => v.toFixed(1) },
    { key: "roubo", label: "Roubos" },
    { key: "furto", label: "Furtos" },
    { key: "trafico", label: "Trafico" },
  ];

  const dataWithPos = municipioData.map((m, i) => ({ ...m, pos: i + 1 }));

  const handleDownload = () => {
    downloadCSV(municipioData, [
      { key: "nome", label: "Municipio" },
      { key: "pop", label: "Populacao" },
      { key: "homicidio", label: "Homicidios" },
      { key: "cvli", label: "CVLI" },
      { key: "taxa_cvli", label: "Taxa CVLI/100mil" },
      { key: "roubo", label: "Roubos" },
      { key: "furto", label: "Furtos" },
      { key: "trafico", label: "Trafico" },
    ], "ranking_municipal_to_2025");
  };

  return (
    <div>
      <ChartCard title="Top 10 Municipios - CVLI (2025)" onDownload={handleDownload}>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={municipioData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
            <XAxis type="number" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={{ stroke: COLORS.border }} />
            <YAxis dataKey="nome" type="category" tick={{ fill: COLORS.textSecondary, fontSize: 11 }} width={130} axisLine={{ stroke: COLORS.border }} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="cvli" name="CVLI" fill={COLORS.red} radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ marginTop: 20 }}>
        <DataTable 
          data={dataWithPos} 
          columns={columns} 
          title="Detalhamento por Municipio"
          onDownload={handleDownload}
        />
      </div>
    </div>
  );
}

function Metodologia() {
  return (
    <ChartCard>
      <h3 style={{ fontSize: 18, color: COLORS.gold, fontFamily: "'Playfair Display', serif", marginBottom: 20 }}>
        Nota Metodologica
      </h3>
      {[
        { t: "Orgao Responsavel", d: "Secretaria da Seguranca Publica do Estado do Tocantins (SSP-TO), por meio da Gerencia de Estatistica e Analise Criminal (GEAC)." },
        { t: "Fontes de Dados", d: "Sistema Integrado de Gestao Operacional (SIGO), Boletim de Ocorrencia Eletronico (BOe), sistemas da Policia Militar, Policia Civil e Corpo de Bombeiros Militar do Tocantins." },
        { t: "CVLI", d: "Crimes Violentos Letais Intencionais: soma de homicidio doloso, latrocinio, lesao corporal seguida de morte e morte por intervencao policial. Metodologia alinhada ao SINESP/MJSP." },
        { t: "Taxa por 100 mil", d: "Calculada com base na populacao estimada pelo IBGE para o ano de referencia. Formula: (n de ocorrencias / populacao) x 100.000." },
        { t: "Periodicidade", d: "Indicadores atualizados mensalmente, com publicacao ate o 15o dia util do mes subsequente." },
        { t: "Exportacao CSV", d: "Todos os dados podem ser baixados em formato CSV (separador ponto e virgula) para analise em Excel, R, Python ou outras ferramentas estatisticas." },
        { t: "Limitacoes", d: "Os dados refletem registros oficiais e podem apresentar subnotificacao. O painel nao substitui pesquisas vitimologicas ou de prevalencia." },
        { t: "Contato", d: "geac@ssp.to.gov.br" },
      ].map((item, i) => (
        <div key={i} style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.cream, fontFamily: "'Cinzel', serif", letterSpacing: 0.5, marginBottom: 4 }}>
            {item.t}
          </div>
          <div style={{ fontSize: 13, color: COLORS.textSecondary, lineHeight: 1.6 }}>
            {item.d}
          </div>
        </div>
      ))}

      <div style={{ marginTop: 32, padding: 20, background: COLORS.bg, borderRadius: 8, border: `1px solid ${COLORS.borderGold}` }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.gold, marginBottom: 12 }}>Glossario Resumido</div>
        {[
          { t: "CVLI", d: "Crimes Violentos Letais Intencionais" },
          { t: "Homicidio Doloso", d: "Morte causada intencionalmente (art. 121, CP)" },
          { t: "Latrocinio", d: "Roubo seguido de morte (art. 157, par. 3o, CP)" },
          { t: "Roubo", d: "Subtracao mediante grave ameaca ou violencia (art. 157, CP)" },
          { t: "Furto", d: "Subtracao sem violencia ou grave ameaca (art. 155, CP)" },
          { t: "Trafico de Drogas", d: "Lei n. 11.343/2006, arts. 33 a 37" },
          { t: "AISP", d: "Area Integrada de Seguranca Publica" },
        ].map((item, i) => (
          <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6, fontSize: 12 }}>
            <span style={{ color: COLORS.gold, fontWeight: 600, minWidth: 120 }}>{item.t}:</span>
            <span style={{ color: COLORS.textSecondary }}>{item.d}</span>
          </div>
        ))}
      </div>
    </ChartCard>
  );
}

// === MAIN APP ===
export default function ObservatorioSegurancaTO() {
  const [activeTab, setActiveTab] = useState("visao");
  const [periodo, setPeriodo] = useState("2025");

  const tabContent = {
    visao: <VisaoGeral />,
    crimes: <CrimesViolentos />,
    patrimonio: <CrimesPatrimoniais />,
    operacional: <Operacional />,
    territorio: <Territorio />,
    ranking: <RankingMunicipal />,
    metodologia: <Metodologia />,
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: `linear-gradient(180deg, ${COLORS.bg} 0%, #060410 100%)`,
      color: COLORS.cream,
      fontFamily: "'Segoe UI', -apple-system, sans-serif",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet" />

      {/* HEADER */}
      <header style={{
        background: `linear-gradient(135deg, ${COLORS.bg} 0%, #12091e 50%, ${COLORS.bg} 100%)`,
        borderBottom: `1px solid ${COLORS.borderGold}`,
        padding: "20px 32px",
        position: "sticky", top: 0, zIndex: 100,
        backdropFilter: "blur(12px)",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 1400, margin: "0 auto" }}>
          <div>
            <div style={{ fontSize: 11, color: COLORS.textMuted, letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>
              SSP-TO | GEAC
            </div>
            <h1 style={{
              fontSize: 22, fontWeight: 700, color: COLORS.gold,
              fontFamily: "'Cinzel', serif", letterSpacing: 1.5, margin: 0,
            }}>
              OBSERVATORIO DE SEGURANCA PUBLICA
            </h1>
            <div style={{ fontSize: 12, color: COLORS.textSecondary, marginTop: 2, fontFamily: "'Playfair Display', serif" }}>
              Estado do Tocantins
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 10, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Ultima Atualizacao</div>
            <div style={{ fontSize: 13, color: COLORS.goldLight, fontWeight: 600 }}>15/03/2026</div>
            <div style={{
              marginTop: 6, display: "inline-block",
              background: COLORS.green + "22", border: `1px solid ${COLORS.green}44`,
              borderRadius: 12, padding: "2px 10px", fontSize: 10, color: COLORS.green,
            }}>
              DADOS ABERTOS
            </div>
          </div>
        </div>
      </header>

      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px 60px" }}>
        {/* FILTROS */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "16px 0", marginBottom: 8,
          borderBottom: `1px solid ${COLORS.border}`,
        }}>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <span style={{ fontSize: 11, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>Periodo:</span>
            {["2023", "2024", "2025"].map(y => (
              <button key={y} onClick={() => setPeriodo(y)} style={{
                background: periodo === y ? COLORS.gold + "22" : "transparent",
                border: `1px solid ${periodo === y ? COLORS.gold : COLORS.border}`,
                color: periodo === y ? COLORS.gold : COLORS.textSecondary,
                borderRadius: 6, padding: "5px 14px", fontSize: 12, cursor: "pointer",
                transition: "all 0.2s",
              }}>
                {y}
              </button>
            ))}
          </div>
          <div style={{ fontSize: 11, color: COLORS.textMuted }}>
            Exporte os dados em CSV para analise
          </div>
        </div>

        {/* TABS */}
        <div style={{
          display: "flex", gap: 0, marginBottom: 24,
          borderBottom: `1px solid ${COLORS.border}`,
          overflowX: "auto",
        }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              background: "transparent",
              border: "none",
              borderBottom: activeTab === tab.id ? `2px solid ${COLORS.gold}` : "2px solid transparent",
              color: activeTab === tab.id ? COLORS.gold : COLORS.textSecondary,
              padding: "12px 20px",
              fontSize: 12,
              fontFamily: "'Cinzel', serif",
              letterSpacing: 1,
              textTransform: "uppercase",
              cursor: "pointer",
              transition: "all 0.2s",
              whiteSpace: "nowrap",
            }}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* CONTENT */}
        {tabContent[activeTab]}
      </div>

      {/* FOOTER */}
      <footer style={{
        borderTop: `1px solid ${COLORS.borderGold}`,
        padding: "20px 32px",
        textAlign: "center",
        background: COLORS.bg,
      }}>
        <div style={{ fontSize: 11, color: COLORS.textMuted, lineHeight: 1.8 }}>
          <div>Secretaria da Seguranca Publica do Estado do Tocantins (SSP-TO)</div>
          <div>Gerencia de Estatistica e Analise Criminal (GEAC)</div>
          <div style={{ marginTop: 8, fontSize: 10, color: COLORS.textMuted }}>
            Dados anonimizados e agregados em conformidade com a LGPD (Lei n. 13.709/2018).
          </div>
          <div style={{ marginTop: 4, fontSize: 10, color: COLORS.textMuted }}>
            ESBOCO / PROTOTIPO - Dados simulados para fins de demonstracao do layout.
          </div>
        </div>
      </footer>
    </div>
  );
}
